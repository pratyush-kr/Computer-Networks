#include<stdio.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<string.h>
#include<stdlib.h>

int main()
{
    struct sockaddr_in saddr;
    saddr.sin_family = AF_INET;
    saddr.sin_port = htons(5000);
    saddr.sin_addr.s_addr = INADDR_ANY;
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if(fd < 0)
    {
        printf("Building socket failed\n");
        exit(-1);
    }
    printf("Socket Creation Sucessfull\n");
    if(connect(fd, (struct sockaddr*)&saddr, sizeof(saddr)) < 0)
    {
        printf("Connection Failed\n");
        exit(-1);
    }
    printf("Connected to server\n");
    char buffer[255];
    printf("Enter Data for Client: ");
    scanf(" %[^\n]%*c", buffer);
    send(fd, buffer, strlen(buffer), 0);
    int n = recv(fd, buffer, sizeof(buffer), 0);
    buffer[n] = '\0';
    printf("Server: %s\n", buffer);
    close(fd);
    return 0;
}